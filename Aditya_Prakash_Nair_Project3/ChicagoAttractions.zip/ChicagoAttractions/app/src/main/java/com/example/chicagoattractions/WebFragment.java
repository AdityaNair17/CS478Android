package com.example.chicagoattractions;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link WebFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class WebFragment extends Fragment {

    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String URLS = "URLS";
    private ListViewModal model;
    private List<String> urlList;
    private int currentIndex = -1;
    private WebView webView;
    private static final String TAG = "WebFragment";


    public WebFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param urls Parameter 1.
     * @return A new instance of fragment WebFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static WebFragment newInstance(ArrayList<String> urls) {
        WebFragment fragment = new WebFragment();
        Bundle args = new Bundle();
        args.putStringArrayList(URLS, urls);
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onAttach(@NonNull Context activity) {
        super.onAttach(activity);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, getClass().getSimpleName() + ":entered onCreate()");
        setRetainInstance(true);
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            urlList = getArguments().getStringArrayList(URLS);
        }
//        model.getUrlList().observe(getViewLifecycleOwner(), urls -> {
//            urlList = urls;
//        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_web, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.i(TAG, getClass().getSimpleName() + ":entered onActivityCreated()");

        super.onViewCreated(view, savedInstanceState);

        webView = view.findViewById(R.id.webView);
        model = new ViewModelProvider(requireActivity()).get(ListViewModal.class);

        model.getSelectedItem().observe(getViewLifecycleOwner(), selectedItem -> {
            if(selectedItem < 0 || selectedItem >= urlList.size()){
                return;
            }
//            Log.i("WEBS FRAGMENT", "Selected = " + selectedItem);
//            Log.i("WEBS FRAGMENT", "Selected = " + urlList.get(selectedItem));
            webView.setWebViewClient(new WebViewClient(){
             @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url)
            {
                //view.loadUrl(url);
//                System.out.println("hello");
                return false;
            }
        });
            currentIndex = selectedItem;
            webView.getSettings().setJavaScriptEnabled(true);
            webView.loadUrl(urlList.get(selectedItem));

        });
    }

    @Override
    public void onStart() {
        Log.i(TAG, getClass().getSimpleName() + ":entered onStart()");
        super.onStart();
    }

    @Override
    public void onResume() {
        Log.i(TAG, getClass().getSimpleName() + ":entered onResume()");
        super.onResume();
    }


    @Override
    public void onPause() {
        Log.i(TAG, getClass().getSimpleName() + ":entered onPause()");
        super.onPause();
    }

    @Override
    public void onStop() {
        Log.i(TAG, getClass().getSimpleName() + ":entered onStop()");
        super.onStop();
    }

    @Override
    public void onDetach() {
//        currentIndex = -1;
        Log.i(TAG, getClass().getSimpleName() + ":entered onDetach()");
        super.onDetach();
    }


    @Override
    public void onDestroy() {
        Log.i(TAG, getClass().getSimpleName() + ":entered onDestroy()");
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
//        currentIndex = -1;
        Log.i(TAG, getClass().getSimpleName() + ":entered onDestroyView()");
        super.onDestroyView();
    }

}