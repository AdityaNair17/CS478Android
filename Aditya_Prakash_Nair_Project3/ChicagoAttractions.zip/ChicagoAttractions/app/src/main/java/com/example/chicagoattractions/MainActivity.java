package com.example.chicagoattractions;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    public static final String ATTRACTION_INTENT = "ATTRACTION";
    public static final String RESTAURANT_INTENT = "RESTAURANT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AttractionReceiver attractionReceiver = new AttractionReceiver();
        IntentFilter attractionFilter = new IntentFilter(ATTRACTION_INTENT);
        registerReceiver(attractionReceiver,attractionFilter);

        RestaurantReceiver restaurantReceiver = new RestaurantReceiver();
        IntentFilter restaurantFilter = new IntentFilter(RESTAURANT_INTENT);
        registerReceiver(restaurantReceiver, restaurantFilter);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.restaurants){
            Intent intent = new Intent(this, RestaurantActivity.class);
            startActivity(intent);
        } else {
            Intent intent = new Intent(this, AttractionActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}