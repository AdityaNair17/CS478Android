package com.example.chicagoattractions;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class AttractionActivity extends AppCompatActivity {

    public ArrayList<String> titleList, urlList;
    private FrameLayout titleLayout, webLayout;
    private FragmentManager fragmentManager;
    private static final int MATCH_PARENT = LinearLayout.LayoutParams.MATCH_PARENT;
    public static final String TITLE = "TITLE";
    public static final String URLS = "URLS";
    private ListViewModal model;
    private WebFragment webFragment;
    TitleFragment titleFragment;
    AttractionReceiver attractionReceiver;
    RestaurantReceiver restaurantReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attraction);

        populateTitleList();
        populateUrlList();

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Welcome to Chicago");
        actionBar.setSubtitle("Popular Attractions");

        titleLayout = (FrameLayout) findViewById(R.id.title_fragment_container);
        webLayout = (FrameLayout) findViewById(R.id.web_fragment_container);

        fragmentManager = getSupportFragmentManager();

        if(savedInstanceState == null){
            titleFragment = new TitleFragment();
            webFragment = new WebFragment();
        } else {
            titleFragment = (TitleFragment) fragmentManager.findFragmentByTag(TITLE);
//            Log.i("TITLES","title exist " + titleFragment);
            webFragment = (WebFragment) fragmentManager.findFragmentByTag(URLS);
            if(webFragment == null) {
                webFragment = new WebFragment();
            }
        }

        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        Bundle bundle = new Bundle();
        bundle.putStringArrayList(TITLE,titleList);
        titleFragment.setArguments(bundle);
//        Log.i("Attraction Activity", "Array is available" + titleFragment);
        fragmentTransaction.replace(
                R.id.title_fragment_container,
                titleFragment,
                TITLE
        );

        fragmentTransaction.commit();

        fragmentManager.addOnBackStackChangedListener(
                new FragmentManager.OnBackStackChangedListener() {
                    public void onBackStackChanged() {
                        setLayout();
                    }
                }
        );


        model = new ViewModelProvider(this).get(ListViewModal.class);
        model.getSelectedItem().observe(this, selectedItem -> {
            if (!webFragment.isAdded()) {
//                Log.i("Attraction Activity","Added");
                FragmentTransaction fragmentWebTransaction = fragmentManager.beginTransaction();

                Bundle webBundle = new Bundle();
                webBundle.putStringArrayList(URLS, urlList);
                webFragment.setArguments(webBundle);

                fragmentWebTransaction.replace(R.id.web_fragment_container, webFragment, URLS);

                fragmentWebTransaction.addToBackStack(null);
                fragmentWebTransaction.commit();
                fragmentManager.executePendingTransactions();
        }
        });
        setLayout();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.restaurants){
            Intent intent = new Intent(this, RestaurantActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void populateTitleList(){
        titleList = new ArrayList<>();
        titleList.add("TILT!");
        titleList.add("Navy Pier");
        titleList.add("The Museum of Science and Industry");
        titleList.add("The Art Institute of Chicago");
        titleList.add("Field Museum");
    }

    private void populateUrlList(){
        urlList = new ArrayList<>();
        urlList.add("https://360chicago.com/tilt");
        urlList.add("https://navypier.org/");
        urlList.add("https://www.msichicago.org/");
        urlList.add("https://www.artic.edu/");
        urlList.add("https://www.fieldmuseum.org/");
    }

    private void setLayout(){

        if(!webFragment.isAdded()){
            titleLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    MATCH_PARENT, MATCH_PARENT));
            webLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                    MATCH_PARENT));
        } else {
            titleLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                    MATCH_PARENT, 1f));
            webLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                    MATCH_PARENT, 2f));
        }
    }
}