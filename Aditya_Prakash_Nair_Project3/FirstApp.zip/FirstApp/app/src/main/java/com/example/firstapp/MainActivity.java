package com.example.firstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String ATTRACTION_INTENT = "ATTRACTION";
    public static final String RESTAURANT_INTENT = "RESTAURANT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button attractionsButton = (Button) findViewById(R.id.attractions);
        attractionsButton.setOnClickListener(attractionButtonClickListener);
        Button restaurantButton = (Button) findViewById(R.id.restaurants);
        restaurantButton.setOnClickListener(restaurantsButtonClickListener);


    }


    public View.OnClickListener attractionButtonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Toast.makeText(getApplicationContext(), "Navigating to Popular Attractions", Toast.LENGTH_SHORT ).show();
            Intent aIntent = new Intent(ATTRACTION_INTENT) ;
            sendBroadcast(aIntent, null) ;
            finish();
        }
    };

    public View.OnClickListener restaurantsButtonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Toast.makeText(getApplicationContext(), "Navigating to Popular Restaurants", Toast.LENGTH_SHORT ).show();
            Intent restaurantIntent = new Intent(RESTAURANT_INTENT) ;
            sendBroadcast(restaurantIntent, null) ;
            finish();
        }
    };

}