package com.example.chicagoattractions;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class ListViewModal extends ViewModel {

    private final MutableLiveData<Integer> selectedItem = new MutableLiveData<Integer>();
    private final MutableLiveData<List<String>> urlList = new MutableLiveData<>();
    private final MutableLiveData<List<String>> titlesList = new MutableLiveData<>();


    public LiveData<Integer> getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(Integer item){
        selectedItem.setValue(item);
    }

    public LiveData<List<String>> getUrlList() {
        return urlList;
    }

    public void setUrlList(List<String> url){
        urlList.setValue(url);
    }

    public LiveData<List<String>> getTitlesList() {
        return titlesList;
    }

    public void setTitlesList(List<String> titles){
        titlesList.setValue(titles);
    }
}
